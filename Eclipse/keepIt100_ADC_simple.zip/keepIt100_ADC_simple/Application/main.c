/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 * @defgroup nrf_adc_example main.c
 * @{
 * @ingroup nrf_adc_example
 * @brief ADC Example Application main file.
 *
 * This file contains the source code for a sample application using ADC.
 *
 * @image html example_board_setup_a.jpg "Use board setup A for this example."
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "nrf.h"
#include "nrf_gpio.h"
#include "Ladybug_keepIt100.h"
#include "nrf_adc.h"
#include "SEGGER_RTT.h"
//schematic has p0.30 set aside for the gpio pin that opens/closes FET that turns on battery level check circuit
#define BAT_pin  30
#define UNUSED_VARIABLE(X)  ((void)(X))
void didGetADCReading(float average, float minimum, float maximum){
  SEGGER_RTT_WriteString (0, "--> in didReadADC\n");
  //dummy line to break in debugger
  float avg = average;
  UNUSED_VARIABLE(avg);
}
/**
 * @brief Function for main application entry.
 */
int main(void)
{
  //the battery level check circuit is not connected unless the mosfet is switched
  nrf_gpio_cfg_output (BAT_pin);
  nrf_gpio_pin_set (BAT_pin);
  //get the ADC's conversion of the battery level check voltage
 keepIt100(NRF_ADC_CONFIG_INPUT_2,didGetADCReading);
 nrf_gpio_pin_clear (BAT_pin);
    while (true)
    {
        // enter into sleep mode
        __SEV();
        __WFE();
        __WFE();
    }
}


