/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 * @defgroup nrf_adc_example main.c
 * @{
 * @ingroup nrf_adc_example
 * @brief ADC Example Application main file.
 *
 * This file contains the source code for a sample application using ADC.
 *
 * @image html example_board_setup_a.jpg "Use board setup A for this example."
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "nrf.h"
#include "nrf_gpio.h"
#include "nrf_adc.h"
#include "nrf_drv_clock.h"
#include "app_timer.h"
#include "Ladybug_Statistic.h"
#include "SEGGER_RTT.h"
//start of settings for the app_timer
#define APP_TIMER_PRESCALER             0                     /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_MAX_TIMERS            1                     /**< Maximum number of simultaneously created timers. */
#define MS_BETWEEN_SAMPLING_ADC		200 		     /* 5 HZ sampling */
#define TIMER_TICKS		        APP_TIMER_TICKS(MS_BETWEEN_SAMPLING_ADC, APP_TIMER_PRESCALER) /**< Battery level measurement interval (ticks). */
//For the queue size I used what was used for the example I copy/pasted.  There
//is an explanation on the Nordic Devzon on the APP_TIMER_OP_QUEUE_SIZE
//https://devzone.nordicsemi.com/question/723/how-big-should-app_timer_op_queue_size-be/
#define APP_TIMER_OP_QUEUE_SIZE         4                       /**< Size of timer operation queues. */
static app_timer_id_t                   m_timer_id;   		/**< Associates this timer within the timers in the queue (right now just using one). */
//end settings for the app_timer APIs
//schematic has p0.30 set aside for the gpio pin that opens/closes FET that turns on battery level check circuit
#define BAT_pin  30
//uses NRF_ADC_CONFIG_DEFAULT which sets to a 1/3 pre-scaling
#define ADC_PRE_SCALING_COMPENSATION      3
#define ADC_REF_VOLTAGE_IN_MILLIVOLTS     1200                                              /**< using the VBG reference voltage (on board) which is 1.2V */
#define ADC_RESULT_IN_MILLI_VOLTS(ADC_VALUE)\
    (((ADC_VALUE) * ADC_REF_VOLTAGE_IN_MILLIVOLTS/255) * ADC_PRE_SCALING_COMPENSATION)
#define	NUM_SAMPLES		100  //number of ADC Samples to take before getting the average
#define THROWOUT		2    //number of initial ADC samples to throw out in an attempt to get a more stable average
//end settings for ADC sampling.
#define UNUSED_VARIABLE(X)  ((void)(X))
float adc_average()
{
  float avg = average();
  return avg;
}
uint16_t adc_read()
{
  volatile int32_t adc_sample = nrf_adc_result_get();
  uint16_t adc_mV = ADC_RESULT_IN_MILLI_VOLTS(adc_sample);
  return adc_mV;
}
void adc_start()
{
  nrf_adc_start();
}
void adc_stop()
{
  nrf_adc_stop();
}
/**
 * @brief ADC initialization.
 */
void adc_init()
{
  const nrf_adc_config_t nrf_adc_config = NRF_ADC_CONFIG_DEFAULT;
  // Initialize and configure ADC
  nrf_adc_configure( (nrf_adc_config_t *)&nrf_adc_config);
  nrf_adc_input_select(NRF_ADC_CONFIG_INPUT_2);
}
static void timeout_handler(void * p_context)
{
  static uint8_t nReadings = 0;
  //  UNUSED_PARAMETER(p_context);
  SEGGER_RTT_WriteString (0, "--> in timeout handler\n");
  nReadings++;
  SEGGER_RTT_printf (0, "--> nReadings : %d\n",nReadings);
  //got the number of readings defined by NUM_SAMPLES
  if (nReadings == NUM_SAMPLES+THROWOUT){
      adc_stop();
      //TBD: Turn off Low frequency clock?
      float avg = adc_average();
      UNUSED_VARIABLE(avg);
      uint32_t err_code = app_timer_stop(m_timer_id);
      APP_ERROR_CHECK(err_code);
  }else if (nReadings > THROWOUT){
      volatile int32_t adc_mV = adc_read();
      SEGGER_RTT_printf (0, "--> ADC mV : %d\n",adc_mV);
      //add the sample to the statistics functions
      add(adc_mV);
  }
}
static void timer_start(void)
{
  uint32_t err_code;
  // Start application timers.
  err_code = app_timer_start(m_timer_id, TIMER_TICKS, NULL);
  APP_ERROR_CHECK(err_code);
}
static void timer_init(void)
{
  //initialize the low frequency cloc
  uint32_t err_code = nrf_drv_clock_init(NULL);
  APP_ERROR_CHECK(err_code);
  nrf_drv_clock_lfclk_request();
  // Initialize timer module.
  APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_MAX_TIMERS, APP_TIMER_OP_QUEUE_SIZE, false);

  // Create timers.
  err_code = app_timer_create(&m_timer_id,
			      APP_TIMER_MODE_REPEATED,
			      timeout_handler);
  APP_ERROR_CHECK(err_code);
}
/**
 * @brief Using the simple routines I ported from an Arduino library
 * These routines came from a C++ class, so they could be structured
 * better.  I was more interested in getting to calculating an average
 * and stdev as a priority over writing decent C code.
 */
void stats_init() {
  //start clean
  clear();
}
/**
 * @brief Function for main application entry.
 */
int main(void)
{
  //the battery level check circuit is not connected unless the mosfet is switched
  nrf_gpio_cfg_output (BAT_pin);
  nrf_gpio_pin_set (BAT_pin);
  stats_init();
  adc_init();
  adc_start();
  timer_init();
  timer_start();
  while (true)
    {
      // enter into sleep mode
      __SEV();
      __WFE();
      __WFE();
    }
}


