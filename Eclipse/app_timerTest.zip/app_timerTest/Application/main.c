/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 *
 * @defgroup blinky_example_main main.c
 * @{
 * @ingroup blinky_example
 * @brief Blinky Example Application main file.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include "nrf.h"
#include "nrf_drv_clock.h"
#include "app_timer.h"
#include "SEGGER_RTT.h"

#define APP_TIMER_PRESCALER             0                     /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_MAX_TIMERS            1                     /**< Maximum number of simultaneously created timers. */
#define MS_BETWEEN_SAMPLING_ADC		2000		      /* e.g.: fire timeout every 2 seconds */
#define BATTERY_LEVEL_CHECK_INTERVAL     APP_TIMER_TICKS(MS_BETWEEN_SAMPLING_ADC, APP_TIMER_PRESCALER) /**< Battery level measurement interval (ticks). */

//For the queue size I used what was used for the example I copy/pasted.  There
//is an explanation on the Nordic Devzon on the APP_TIMER_OP_QUEUE_SIZE
//https://devzone.nordicsemi.com/question/723/how-big-should-app_timer_op_queue_size-be/
#define APP_TIMER_OP_QUEUE_SIZE         4                     /**< Size of timer operation queues. */
static app_timer_id_t                   m_battery_timer_id;   /**< Battery level check timer. */
/**@brief Function for starting application timers.
 */

static void timeout_handler(void * p_context)
{
  //  UNUSED_PARAMETER(p_context);
  SEGGER_RTT_WriteString (0, "--> in timeout handler\n");
}
static void application_timers_start(void)
{
    uint32_t err_code;
    err_code = BATTERY_LEVEL_CHECK_INTERVAL;
    // Start application timers.
    err_code = app_timer_start(m_battery_timer_id, BATTERY_LEVEL_CHECK_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);
}
/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates and starts application timers.
 */
static void timers_init(void)
{
    uint32_t err_code;

    // Initialize timer module.
    APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_MAX_TIMERS, APP_TIMER_OP_QUEUE_SIZE, false);

    // Create timers.
    err_code = app_timer_create(&m_battery_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                timeout_handler);
    APP_ERROR_CHECK(err_code);
}
static void lfclk_config(void)
{
    uint32_t err_code = nrf_drv_clock_init(NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_clock_lfclk_request();
}
/**
 * @brief Function for application main entry.
 */
int main(void)
{
  lfclk_config();
  timers_init();
  application_timers_start();
  while (true)
    {
      __SEV();
      __WFE();
      __WFE();
    }
}


/** @} */
